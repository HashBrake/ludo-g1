from __future__ import annotations

try:
    import pxdex.dh5 as dh5
    import pxdex.dh13 as dh13
    import pxdex.dh15 as dh15

    __all__ = ["dh13", "dh5", "dh15"]
except ImportError:
    raise ImportError(
        "Could not import pxdex bindings. Please make sure the dexhandsdk are installed."
    )
